# Pseudo DNA Cryptography


Educational implementation of Kang Ning's pseudo DNA cryptography idea.


## Run demo


```bash
python -m src.demo